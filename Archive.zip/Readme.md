# Better Github

> A silly little project to swap the green and red on PRs in GitHub.


![new](/example.png)